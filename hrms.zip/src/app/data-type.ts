export interface signup{
    name:string,
    email:string,
    password:string
    passwordres:string

}
export interface login{
    email:any,
    password:string
}